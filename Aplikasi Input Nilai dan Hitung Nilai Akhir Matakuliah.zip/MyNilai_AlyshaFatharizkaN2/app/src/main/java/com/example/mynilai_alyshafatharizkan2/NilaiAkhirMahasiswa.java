package com.example.mynilai_alyshafatharizkan2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class NilaiAkhirMahasiswa extends AppCompatActivity {
    TextView tampilmatkul, tampilnim, tampilnama, tampilnilai, tampilgrade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nilai_akhir_mahasiswa);

        tampilmatkul = findViewById(R.id.txtmatakuliah);
        tampilnim = findViewById(R.id.edtnim);
        tampilnama = findViewById(R.id.edtnama);
        tampilnilai = findViewById(R.id.edtnilaiakhir);
        tampilgrade = findViewById(R.id.edtgradenilai);

        String matakuliah = getIntent().getExtras().getString("Matakuliah");
        String nim = getIntent().getExtras().getString("NIM");
        String nama = getIntent().getExtras().getString("Nama");
        String akhir = getIntent().getExtras().getString("Akhir");
        String grade = getIntent().getExtras().getString("Grade");

        tampilmatkul.setText(matakuliah);
        tampilnim.setText(nim);
        tampilnama.setText(nama);
        tampilnilai.setText(akhir);
        tampilgrade.setText(grade);

    }
}