package com.example.mynilai_alyshafatharizkan2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BobotNilaiMahasiswa extends AppCompatActivity {
    EditText isibobotpresensi, isibobotnilaitugas, isibobotnilaiuts, isibobotnilaiuas;
    Button buttonhitung;
    String grade;
    TextView tvnilaiakhir,tvgradenilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bobot_nilai_mahasiswa);

        isibobotpresensi = findViewById(R.id.editbobotpresensi);
        isibobotnilaitugas = findViewById(R.id.editbobottugas);
        isibobotnilaiuts = findViewById(R.id.editbobotuts);
        isibobotnilaiuas = findViewById(R.id.editbobotuas);
        buttonhitung = findViewById(R.id.hitungnilai);

        String matakuliah = getIntent().getExtras().getString("Matakuliah");
        String nim = getIntent().getExtras().getString("NIM");
        String nama = getIntent().getExtras().getString("Nama");
        Double nilaipresensi = Double.valueOf(getIntent().getExtras().getString("Presensi"));
        Double nilaitugas = Double.valueOf(getIntent().getExtras().getString("Tugas"));
        Double nilaiuts = Double.valueOf(getIntent().getExtras().getString("UTS"));
        Double nilaiuas = Double.valueOf(getIntent().getExtras().getString("UAS"));

        buttonhitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double bbtpresensi = Double.valueOf(isibobotpresensi.getText().toString());
                Double bbttugas = Double.valueOf(isibobotnilaitugas.getText().toString());
                Double bbtuts = Double.valueOf(isibobotnilaiuts.getText().toString());
                Double bbtuas = Double.valueOf(isibobotnilaiuas.getText().toString());

                Double nilaiakhir = ((bbtpresensi * nilaipresensi) + (bbttugas * nilaitugas) + (bbtuts * nilaiuts) + (bbtuas * nilaiuas));

                if (nilaiakhir >= 80) {
                    grade = "A";
                } else if (nilaiakhir >= 65) {
                    grade = "B";
                } else if (nilaiakhir >= 55) {
                    grade = "C";
                } else if (nilaiakhir >= 40) {
                    grade = "D";
                } else {
                    grade = "E";
                }

                tvnilaiakhir = findViewById(R.id.txtakhir);
                tvnilaiakhir.setText(""+nilaiakhir);
                tvgradenilai = findViewById(R.id.txtgrade);
                tvgradenilai.setText(grade);

                Intent hitung = new Intent(BobotNilaiMahasiswa.this,NilaiAkhirMahasiswa.class);
                hitung.putExtra("Akhir", tvnilaiakhir.getText().toString());
                hitung.putExtra("Grade", tvgradenilai.getText().toString());
                hitung.putExtra("Matakuliah", matakuliah);
                hitung.putExtra("NIM", nim);
                hitung.putExtra("Nama", nama);
                startActivity(hitung);
            }
        });

    }
}