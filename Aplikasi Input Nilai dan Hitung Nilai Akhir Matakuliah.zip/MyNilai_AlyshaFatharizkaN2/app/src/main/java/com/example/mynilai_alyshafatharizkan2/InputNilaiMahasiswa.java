package com.example.mynilai_alyshafatharizkan2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class InputNilaiMahasiswa extends AppCompatActivity {
    EditText isinim, isinama, isipresensi, isinilaitugas, isinilaiuts, isinilaiuas;
    Button buttonfoto, buttonsubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_nilai_mahasiswa);

        isinim = findViewById(R.id.editnim);
        isinama = findViewById(R.id.editnama);
        isipresensi = findViewById(R.id.editjumpresensi);
        isinilaitugas = findViewById(R.id.editnilaitugas);
        isinilaiuts = findViewById(R.id.editnilaiuts);
        isinilaiuas = findViewById(R.id.editnilaiuas);
        buttonfoto = findViewById(R.id.foto);
        buttonsubmit = findViewById(R.id.submit);

        String matakuliah = getIntent().getExtras().getString("Matakuliah");

        buttonsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent submit = new Intent(InputNilaiMahasiswa.this,BobotNilaiMahasiswa.class);
                submit.putExtra("Matakuliah", matakuliah);
                submit.putExtra("NIM", isinim.getText().toString());
                submit.putExtra("Nama", isinama.getText().toString());
                submit.putExtra("Presensi", isipresensi.getText().toString());
                submit.putExtra("Tugas", isinilaitugas.getText().toString());
                submit.putExtra("UTS", isinilaiuts.getText().toString());
                submit.putExtra("UAS", isinilaiuas.getText().toString());
                startActivity(submit);
            }
        });

    }
}