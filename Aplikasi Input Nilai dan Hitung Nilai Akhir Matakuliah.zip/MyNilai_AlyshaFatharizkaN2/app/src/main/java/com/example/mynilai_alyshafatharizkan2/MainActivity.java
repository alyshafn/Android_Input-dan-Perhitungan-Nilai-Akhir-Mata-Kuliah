package com.example.mynilai_alyshafatharizkan2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button buttonnext;
    Spinner sp_pilihmatkul;
    String pilihmatkul[] = {"Pilih Matakuliah", "Jaringan Komputer", "IT Essential", "Jaringan Multimedia", "Basis Data Lanjut", "Komputasi Cerdas"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp_pilihmatkul = (Spinner) findViewById(R.id.pilihmatkul);
        buttonnext = findViewById(R.id.next);
        TextView matakuliah = findViewById(R.id.setmatkul);

        ArrayAdapter pilihan = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, pilihmatkul);
        pilihan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_pilihmatkul.setAdapter(pilihan);
        sp_pilihmatkul.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                matakuliah.setText(pilihmatkul[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                matakuliah.setText("Gagal");
            }
        });

        buttonnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent next = new Intent(MainActivity.this,InputNilaiMahasiswa.class);
                next.putExtra("Matakuliah", matakuliah.getText().toString());
                startActivity(next);
            }
        });

    }
}